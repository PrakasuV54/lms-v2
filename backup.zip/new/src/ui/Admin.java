package ui;

import enums.*;
import model.*;

public class Admin extends Main {

    public static void admin() {
        if (currentUser == null || currentUser.getStatus() != UserStatus.ACTIVE || !authService.hasRole(currentUser, UserRole.ADMIN)) {
            System.out.println("Please log in as Admin"); return;
        }
        while (true) {
            try {
                System.out.println("\nAdmin Menu");
                System.out.println("1.View All Books");
                System.out.println("2.Search Books");
                System.out.println("3.Request Book");
                System.out.println("4.Cancel Request");
                System.out.println("5.Renew Book");
                System.out.println("6.Activate Membership");
                System.out.println("7.Renew Membership");
                System.out.println("8.View Currently Rented Books");
                System.out.println("9.View Borrowing History");
                System.out.println("10.Manage Fines");
                System.out.println("11.Update My Profile");
                System.out.println("12.Add Book");
                System.out.println("13.Remove Book Copy");
                System.out.println("14.View Open Requests / Pickup Queue");
                System.out.println("15.Mark Copy Ready for Pickup");
                System.out.println("16.Issue Book");
                System.out.println("17.Process Return");
                System.out.println("18.Mark Copy Lost/Damaged");
                System.out.println("19.View Defaulters");
                System.out.println("20.View Current Fines");
                System.out.println("21.Manage Current Fines");
                System.out.println("22.Manage Membership Status");
                System.out.println("23.Manage Payments");
                System.out.println("24.Dashboard");
                System.out.println("25.Manage Users");
                System.out.println("26.Manage Policies");
                System.out.println("27.Manage Membership Plans");
                System.out.println("28.View Audit Logs");
                System.out.println("29.Logout");
                System.out.println("Enter choice");
                int choice = readInt();
                switch (choice) {
                    case 1: Member.handleViewAllBooks(); break;
                    case 2: Member.handleSearchBooks(); break;
                    case 3: Member.runForTargetMember(Member::handleRequestBook); break;
                    case 4: Member.runForTargetMember(Member::handleCancelRequest); break;
                    case 5: Member.runForTargetMember(Member::handleRenewBook); break;
                    case 6: Member.runForTargetMember(Member::handleActivateMembership); break;
                    case 7: Member.runForTargetMember(Member::handleRenewMembership); break;
                    case 8: Member.runForTargetMember(Member::handleViewCurrentlyRentedBooks); break;
                    case 9: Member.runForTargetMember(Member::handleViewBorrowingHistory); break;
                    case 10: Member.runForTargetMember(Member::handleManageFines); break;
                    case 11: Member.runForTargetMember(Member::handleUpdateProfile); break;
                    case 12: Librarian.handleAddBook(); break;
                    case 13: Librarian.handleRemoveBookCopy(); break;
                    case 14: Librarian.handleViewPendingRequests(); break;
                    case 15: Librarian.handleMarkReadyForPickup(); break;
                    case 16: Librarian.handleIssueBook(); break;
                    case 17: Librarian.handleProcessReturn(); break;
                    case 18: Librarian.handleCopyIncident(); break;
                    case 19: Librarian.handleViewDefaulters(); break;
                    case 20: Librarian.viewCurrentFines(); break;
                    case 21: Librarian.manageCurrentFines(); break;
                    case 22: Librarian.handleManageMembershipStatus(); break;
                    case 23: Librarian.handleManagePayments(); break;
                    case 24: handleDashboard(); break;
                    case 25: handleManageUsers(); break;
                    case 26: handleManagePolicies(); break;
                    case 27: handleManageMembershipPlans(); break;
                    case 28: handleViewAuditLogs(); break;
                    case 29:
                        currentUser = null;
                        System.out.println("Logged out");
                        return;
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (GoHomeException e) {
                // Return to Admin Menu
            }
        }
    }

    public static void handleDashboard() {
        while (true) {
            System.out.println("Enter year for dashboard (0 to cancel)");
            String yearInput = sc.nextLine().trim();
            if (yearInput.equals("0") || isBackCommand(yearInput) || isHomeCommand(yearInput)) return;
            int year;
            try {
                year = Integer.parseInt(yearInput);
                if (year < 1900 || year > 2100) {
                    System.out.println("Please enter a realistic 4-digit year (e.g. 2026).");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid year. Please enter a 4-digit number.");
                continue;
            }
            AnalyticsDashboard dashboard = analyticsService.getDashboardForYear(year);
            dashboard.display();
            return;
        }
    }

    public static void handleManageUsers() {
        while (true) {
            System.out.println("1.View users  2.Add librarian  3.Add admin  4.Activate account  5.Deactivate account  6.Delete user  0.Go to Home");
            int userChoice = readInt();
            if (userChoice == 0) {
                goHome();
            }
            try {
                if (userChoice == 1) {
                    java.util.List<User> users = userService.getAllUsers(currentUser);
                    if (users == null || users.isEmpty()) {
                        System.out.println("No users found.");
                    } else {
                        System.out.println("\n--- Registered Users (" + users.size() + ") ---");
                        for (User user : users) {
                            System.out.println("User ID: " + user.getUserId()
                                    + " | Name: " + user.getName()
                                    + " | Email: " + user.getEmail()
                                    + " | Phone: " + user.getPhone()
                                    + " | Role: " + user.getRole()
                                    + " | Status: " + user.getStatus()
                                    + " | Created: " + user.getCreatedAt());
                        }
                    }
                    return;
                } else if (userChoice == 2 || userChoice == 3) {
                    String name = "";
                    String email = "";
                    String phone = "";
                    String password = "";
                    int step = 1;

                    while (step <= 4) {
                        switch (step) {
                            case 1:
                                System.out.println("Enter name (0 to cancel)");
                                name = sc.nextLine().trim();
                                if (name.equals("0") || isBackCommand(name) || isHomeCommand(name)) return;
                                String nameErr = userService.validateStaffName(name);
                                if (nameErr != null) {
                                    System.out.println(nameErr);
                                    continue;
                                }
                                step = 2;
                                break;
                            case 2:
                                System.out.println("Enter email");
                                email = sc.nextLine().trim();
                                if (isBackCommand(email)) { step = 1; continue; }
                                if (isHomeCommand(email)) return;
                                String emailErr = userService.validateStaffEmail(email);
                                if (emailErr != null) {
                                    System.out.println(emailErr);
                                    continue;
                                }
                                step = 3;
                                break;
                            case 3:
                                System.out.println("Enter phone");
                                phone = sc.nextLine().trim();
                                if (isBackCommand(phone)) { step = 2; continue; }
                                if (isHomeCommand(phone)) return;
                                String phoneErr = userService.validateStaffPhone(phone);
                                if (phoneErr != null) {
                                    System.out.println(phoneErr);
                                    continue;
                                }
                                step = 4;
                                break;
                            case 4:
                                System.out.println("Enter password");
                                password = sc.nextLine();
                                if (isBackCommand(password)) { step = 3; continue; }
                                if (isHomeCommand(password)) return;
                                String pwdErr = userService.validateStaffPassword(password);
                                if (pwdErr != null) {
                                    System.out.println(pwdErr);
                                    continue;
                                }
                                step = 5;
                                break;
                        }
                    }

                    if (userChoice == 2) {
                        userService.addLibrarian(currentUser, name, email, phone, password);
                    } else {
                        userService.addAdmin(currentUser, name, email, phone, password);
                    }
                    System.out.println("User created");
                    return;
                } else if (userChoice >= 4 && userChoice <= 6) {
                    while (true) {
                        System.out.println("Enter user ID (0 to cancel)");
                        String uInput = sc.nextLine().trim();
                        if (uInput.equals("0") || isBackCommand(uInput) || isHomeCommand(uInput)) return;
                        int userId;
                        try {
                            userId = Integer.parseInt(uInput);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input. Please enter a numeric User ID.");
                            continue;
                        }
                        User targetUser = userService.findById(userId);
                        if (targetUser == null) {
                            System.out.println("User not found with ID: " + userId);
                            continue;
                        }

                        if (userChoice == 4) {
                            userService.activateAccount(currentUser, userId);
                        } else if (userChoice == 5) {
                            userService.deactivateAccount(currentUser, userId);
                        } else {
                            userService.deleteUser(currentUser, userId);
                        }
                        System.out.println(userChoice == 6 ? "User deleted" : "User updated");
                        return;
                    }
                } else {
                    System.out.println("Invalid choice");
                    return;
                }
            } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
                String action = userChoice == 2 || userChoice == 3 ? "create user"
                        : userChoice == 4 ? "activate account"
                        : userChoice == 5 ? "deactivate account"
                        : userChoice == 6 ? "delete user" : "manage users";
                System.out.println("Unable to " + action + ": " + e.getMessage());
                return;
            }
        }
    }

    public static void handleManagePolicies() {
        try {
            java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
            if (plans.isEmpty()) {
                System.out.println("No membership plans exist. Create a plan first.");
                return;
            }

            System.out.println("\nSelect the plan whose policies you want to manage:");
            for (MembershipPlan plan : plans) {
                System.out.println("Plan ID: " + plan.getPlanId() + " | " + plan.getPlanName()
                        + " | Max books: " + plan.getMaxBooks()
                        + " | Loan days: " + plan.getLoanPeriodDays()
                        + " | Fine/day: Rs." + plan.getFinePerDay()
                        + " | Lost: Rs." + plan.getLostBookCharge()
                        + " | Damaged: Rs." + plan.getDamagedBookCharge());
            }

            MembershipPlan selected = null;
            int planId = -1;
            while (true) {
                System.out.println("Enter Plan ID (0 to cancel)");
                String pInput = sc.nextLine().trim();
                if (pInput.equals("0") || isBackCommand(pInput) || isHomeCommand(pInput)) return;
                try {
                    planId = Integer.parseInt(pInput);
                    selected = membershipPlanService.findById(planId);
                    if (selected == null) {
                        System.out.println("Unable to manage policies: membership plan not found.");
                        continue;
                    }
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a numeric Plan ID.");
                }
            }

            System.out.println("Managing policies for " + selected.getPlanName() + " (ID " + planId + ")");
            System.out.println("1.Maximum books (" + selected.getMaxBooks() + ")");
            System.out.println("2.Loan days (" + selected.getLoanPeriodDays() + ")");
            System.out.println("3.Fine per day (Rs." + selected.getFinePerDay() + ")");
            System.out.println("4.Lost book charge (Rs." + selected.getLostBookCharge() + ")");
            System.out.println("5.Damaged book charge (Rs." + selected.getDamagedBookCharge() + ")");
            System.out.println("0.Go to Home");
            int choice = readInt();
            if (choice == 0) {
                goHome();
            }

            int maxBooks = selected.getMaxBooks();
            int loanDays = selected.getLoanPeriodDays();
            double fine = selected.getFinePerDay();
            double lost = selected.getLostBookCharge();
            double damaged = selected.getDamagedBookCharge();

            switch (choice) {
                case 1:
                    while (true) {
                        System.out.println("Enter maximum books allowed for " + selected.getPlanName() + " (0 to cancel)");
                        String mbStr = sc.nextLine().trim();
                        if (mbStr.equals("0") || isBackCommand(mbStr)) return;
                        String err = membershipPlanService.validateMaxBooks(mbStr);
                        if (err != null) {
                            System.out.println(err);
                            continue;
                        }
                        maxBooks = Integer.parseInt(mbStr);
                        break;
                    }
                    break;
                case 2:
                    while (true) {
                        System.out.println("Enter loan period in days for " + selected.getPlanName() + " (0 to cancel)");
                        String ldStr = sc.nextLine().trim();
                        if (ldStr.equals("0") || isBackCommand(ldStr)) return;
                        String err = membershipPlanService.validateLoanDays(ldStr);
                        if (err != null) {
                            System.out.println(err);
                            continue;
                        }
                        loanDays = Integer.parseInt(ldStr);
                        break;
                    }
                    break;
                case 3:
                    while (true) {
                        System.out.println("Enter fine per overdue day for " + selected.getPlanName() + " (0 to cancel)");
                        String fineStr = sc.nextLine().trim();
                        if (isBackCommand(fineStr)) return;
                        String err = membershipPlanService.validateCharge(fineStr, "Fine per day");
                        if (err != null) {
                            System.out.println(err);
                            continue;
                        }
                        fine = Double.parseDouble(fineStr);
                        break;
                    }
                    break;
                case 4:
                    while (true) {
                        System.out.println("Enter lost book charge for " + selected.getPlanName() + " (0 to cancel)");
                        String lostStr = sc.nextLine().trim();
                        if (isBackCommand(lostStr)) return;
                        String err = membershipPlanService.validateCharge(lostStr, "Lost book charge");
                        if (err != null) {
                            System.out.println(err);
                            continue;
                        }
                        lost = Double.parseDouble(lostStr);
                        break;
                    }
                    break;
                case 5:
                    while (true) {
                        System.out.println("Enter damaged book charge for " + selected.getPlanName() + " (0 to cancel)");
                        String dmgStr = sc.nextLine().trim();
                        if (isBackCommand(dmgStr)) return;
                        String err = membershipPlanService.validateCharge(dmgStr, "Damaged book charge");
                        if (err != null) {
                            System.out.println(err);
                            continue;
                        }
                        damaged = Double.parseDouble(dmgStr);
                        break;
                    }
                    break;
                default:
                    System.out.println("Invalid choice");
                    return;
            }

            MembershipPlan updated = membershipPlanService.updatePlanPolicies(currentUser, planId,
                    maxBooks, loanDays, fine, lost, damaged);
            System.out.println("Policy updated for " + updated.getPlanName() + " only.");
        } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
            System.out.println("Unable to manage policies: " + e.getMessage());
        }
    }

    public static void handleManageMembershipPlans() {
        try {
            System.out.println("1.View All Plans  2.Create Plan  0.Go to Home");
            int planChoice = readInt();
            if (planChoice == 0) {
                goHome();
            }

            if (planChoice == 1) {
                java.util.List<MembershipPlan> plans = membershipPlanService.getAllPlans();
                if (plans.isEmpty()) {
                    System.out.println("No membership plans exist.");
                    return;
                }
                for (MembershipPlan p : plans) {
                    System.out.println("Plan ID: " + p.getPlanId() + ", Name: " + p.getPlanName()
                            + ", Amount: Rs." + p.getAmount()
                            + ", Max books: " + p.getMaxBooks()
                            + ", Loan days: " + p.getLoanPeriodDays()
                            + ", Fine/day: Rs." + p.getFinePerDay()
                            + ", Lost charge: Rs." + p.getLostBookCharge()
                            + ", Damaged charge: Rs." + p.getDamagedBookCharge());
                }
            } else if (planChoice == 2) {
                String planName = "";
                double planAmount = 0;
                int maxBooks = 0;
                int loanDays = 0;
                double finePerDay = 0;
                double lostCharge = 0;
                double damagedCharge = 0;
                int step = 1;

                while (step <= 7) {
                    switch (step) {
                        case 1:
                            System.out.println("Enter plan name (0 to cancel)");
                            planName = sc.nextLine().trim();
                            if (planName.equals("0") || isBackCommand(planName) || isHomeCommand(planName)) return;
                            String nameErr = membershipPlanService.validatePlanName(planName);
                            if (nameErr != null) {
                                System.out.println(nameErr);
                                continue;
                            }
                            step = 2;
                            break;
                        case 2:
                            System.out.println("Enter plan amount");
                            String amtStr = sc.nextLine().trim();
                            if (isBackCommand(amtStr)) { step = 1; continue; }
                            if (isHomeCommand(amtStr)) return;
                            String amtErr = membershipPlanService.validatePlanAmount(amtStr);
                            if (amtErr != null) {
                                System.out.println(amtErr);
                                continue;
                            }
                            planAmount = Double.parseDouble(amtStr);
                            step = 3;
                            break;
                        case 3:
                            System.out.println("Enter maximum books that can be borrowed at once");
                            String mbStr = sc.nextLine().trim();
                            if (isBackCommand(mbStr)) { step = 2; continue; }
                            if (isHomeCommand(mbStr)) return;
                            String mbErr = membershipPlanService.validateMaxBooks(mbStr);
                            if (mbErr != null) {
                                System.out.println(mbErr);
                                continue;
                            }
                            maxBooks = Integer.parseInt(mbStr);
                            step = 4;
                            break;
                        case 4:
                            System.out.println("Enter loan period in days");
                            String ldStr = sc.nextLine().trim();
                            if (isBackCommand(ldStr)) { step = 3; continue; }
                            if (isHomeCommand(ldStr)) return;
                            String ldErr = membershipPlanService.validateLoanDays(ldStr);
                            if (ldErr != null) {
                                System.out.println(ldErr);
                                continue;
                            }
                            loanDays = Integer.parseInt(ldStr);
                            step = 5;
                            break;
                        case 5:
                            System.out.println("Enter fine per overdue day (Rs.; 0 to disable)");
                            String fineStr = sc.nextLine().trim();
                            if (isBackCommand(fineStr)) { step = 4; continue; }
                            if (isHomeCommand(fineStr)) return;
                            String fineErr = membershipPlanService.validateCharge(fineStr, "Fine per day");
                            if (fineErr != null) {
                                System.out.println(fineErr);
                                continue;
                            }
                            finePerDay = Double.parseDouble(fineStr);
                            step = 6;
                            break;
                        case 6:
                            System.out.println("Enter lost book charge (Rs.; 0 if not applicable)");
                            String lostStr = sc.nextLine().trim();
                            if (isBackCommand(lostStr)) { step = 5; continue; }
                            if (isHomeCommand(lostStr)) return;
                            String lostErr = membershipPlanService.validateCharge(lostStr, "Lost book charge");
                            if (lostErr != null) {
                                System.out.println(lostErr);
                                continue;
                            }
                            lostCharge = Double.parseDouble(lostStr);
                            step = 7;
                            break;
                        case 7:
                            System.out.println("Enter damaged book charge (Rs.; 0 if not applicable)");
                            String dmgStr = sc.nextLine().trim();
                            if (isBackCommand(dmgStr)) { step = 6; continue; }
                            if (isHomeCommand(dmgStr)) return;
                            String dmgErr = membershipPlanService.validateCharge(dmgStr, "Damaged book charge");
                            if (dmgErr != null) {
                                System.out.println(dmgErr);
                                continue;
                            }
                            damagedCharge = Double.parseDouble(dmgStr);
                            step = 8;
                            break;
                    }
                }

                MembershipPlan created = membershipPlanService.createPlan(currentUser, planName, planAmount,
                        maxBooks, loanDays, finePerDay, lostCharge, damagedCharge);
                System.out.println("Plan created successfully: " + created.getPlanName());
            } else {
                System.out.println("Invalid choice");
            }
        } catch (SecurityException | IllegalArgumentException | IllegalStateException e) {
            System.out.println("Unable to manage membership plans: " + e.getMessage());
        }
    }
}
