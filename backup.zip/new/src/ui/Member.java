package ui;

import enums.BookStatus;
import enums.PaymentMethod;
import enums.PaymentStatus;
import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import service.AuthService;
import java.util.*;

public class Member extends Main {



    public static void member() {
        System.out.println("1.Login or 2.Register or 3.Exit or 0.Go to Home");
        int loginChoice = readInt();

        switch (loginChoice) {
            case 0:
                return;
            case 1:
                while (true) {
                    System.out.println("Enter Mobile or Email");
                    String identifier = sc.nextLine().trim();
                    if (isBackCommand(identifier)) break;
                    if (isHomeCommand(identifier)) return;
                    if (identifier.isEmpty()) {
                        System.out.println("Login Failed: Phone/Email and password cannot be empty. Please enter your credentials.");
                        continue;
                    }

                    boolean backToId = false;
                    while (true) {
                        System.out.println("Enter Password");
                        String loginPassword = sc.nextLine();
                        if (isBackCommand(loginPassword)) {
                            backToId = true;
                            break;
                        }
                        if (isHomeCommand(loginPassword)) return;
                        if (loginPassword.isEmpty()) {
                            System.out.println("Login Failed: Phone/Email and password cannot be empty. Please enter your credentials.");
                            continue;
                        }

                        User user = authService.login(identifier, loginPassword);
                        if (user != null) {
                            if (user.getRole() != UserRole.MEMBER) {
                                currentUser = null;
                                System.out.println("Login Failed: This account is registered as " + user.getRole() + ". Please log in via the Librarian or Admin menu.");
                                backToId = true;
                                break;
                            }
                            if (user.getStatus() != UserStatus.ACTIVE) {
                                currentUser = null;
                                System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                                backToId = true;
                                break;
                            }
                            currentUser = user;
                            System.out.println("Login Success");
                            memberMenu();
                            return;
                        } else {
                            User existing = userService.findByPhone(identifier);
                            if (existing == null) existing = userService.findByEmail(identifier);
                            if (existing != null && existing.getStatus() == UserStatus.INACTIVE) {
                                System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                                backToId = true;
                                break;
                            } else {
                                System.out.println("Login Failed: Invalid credentials. Please check your phone/email and password, or register for a new account.");
                                continue;
                            }
                        }
                    }
                    if (!backToId) {
                        break;
                    }
                }
                break;

            case 2:
                String name = "";
                String phone = "";
                String email = "";
                int age = 0;
                String gender = "";
                String registerPassword = "";
                String confirmPassword = "";
                int regStep = 1;

                while (regStep <= 7) {
                    switch (regStep) {
                        case 1:
                            System.out.println("Enter your name");
                            name = sc.nextLine().trim();
                            if (isBackCommand(name) || isHomeCommand(name)) { return; }
                            String nameErr = userService.validateName(name);
                            if (nameErr != null) {
                                System.out.println("Registration failed: " + nameErr);
                                continue;
                            }
                            regStep = 2;
                            break;

                        case 2:
                            System.out.println("Enter your phone number");
                            phone = sc.nextLine().trim();
                            if (isBackCommand(phone)) { regStep = 1; continue; }
                            if (isHomeCommand(phone)) { return; }
                            String phoneErr = userService.validateRegistrationPhone(phone);
                            if (phoneErr != null) {
                                System.out.println("Registration failed: " + phoneErr);
                                continue;
                            }
                            regStep = 3;
                            break;

                        case 3:
                            System.out.println("Enter your email");
                            email = sc.nextLine().trim();
                            if (isBackCommand(email)) { regStep = 2; continue; }
                            if (isHomeCommand(email)) { return; }
                            String emailErr = userService.validateRegistrationEmail(email);
                            if (emailErr != null) {
                                System.out.println("Registration failed: " + emailErr);
                                continue;
                            }
                            regStep = 4;
                            break;

                        case 4:
                            System.out.println("Enter your age");
                            String ageInput = sc.nextLine().trim();
                            if (isBackCommand(ageInput)) { regStep = 3; continue; }
                            if (isHomeCommand(ageInput)) { return; }
                            String ageErr = userService.validateAge(ageInput);
                            if (ageErr != null) {
                                System.out.println("Registration failed: " + ageErr);
                                continue;
                            }
                            age = Integer.parseInt(ageInput);
                            regStep = 5;
                            break;

                        case 5:
                            System.out.println("Enter your gender (MALE/FEMALE/NON_BINARY/OTHER/PREFER_NOT_TO_SAY)");
                            gender = sc.nextLine().trim().toUpperCase();
                            if (isBackCommand(gender)) { regStep = 4; continue; }
                            if (isHomeCommand(gender)) { return; }
                            String genderErr = userService.validateGender(gender);
                            if (genderErr != null) {
                                System.out.println("Registration failed: " + genderErr);
                                continue;
                            }
                            regStep = 6;
                            break;

                        case 6:
                            System.out.println("Enter your password");
                            registerPassword = sc.nextLine();
                            if (isBackCommand(registerPassword)) { regStep = 5; continue; }
                            if (isHomeCommand(registerPassword)) { return; }
                            String pwdErr = userService.validateMemberPassword(registerPassword);
                            if (pwdErr != null) {
                                System.out.println("Registration failed: " + pwdErr);
                                continue;
                            }
                            regStep = 7;
                            break;

                        case 7:
                            System.out.println("Enter your password again");
                            confirmPassword = sc.nextLine();
                            if (isBackCommand(confirmPassword)) { regStep = 6; continue; }
                            if (isHomeCommand(confirmPassword)) { return; }
                            if (!registerPassword.equals(confirmPassword)) {
                                System.out.println("Registration failed: Passwords do not match.");
                                continue;
                            }
                            regStep = 8;
                            break;
                    }
                }

                String regReason = userService.getRegistrationFailureReason(name, email, phone, confirmPassword);
                if (regReason != null) {
                    System.out.println("Registration failed: " + (regReason != null ? regReason : "Unable to create user account. Please check your details."));
                    break;
                }
                authService.register(name, email, phone, confirmPassword);
                System.out.println("Registration successful. Your account and profile details have been saved.");
                break;

            case 3:
                return;

            default:
                System.out.println("Invalid Input");
        }
    }

    public static void memberMenu() {
        while (true) {
            try {
                System.out.println("\n1.View All Books");
                System.out.println("2.Search Books");
                System.out.println("3.Request Book");
                System.out.println("4.Cancel Request");
                System.out.println("5.Renew Book");
                System.out.println("6.Activate Membership");
                System.out.println("7.Renew Membership");
                System.out.println("8.View Currently Rented Books");
                System.out.println("9.View Borrowing History");
                System.out.println("10.Manage Fines");
                System.out.println("11.Update Profile");
                System.out.println("12.Logout");
                System.out.println("Enter Your Choice");

                int choice = readInt();

                switch (choice) {
                    case 1:
                        handleViewAllBooks();
                        break;
                    case 2:
                        handleSearchBooks();
                        break;
                    case 3:
                        handleRequestBook();
                        break;
                    case 4:
                        handleCancelRequest();
                        break;
                    case 5:
                        handleRenewBook();
                        break;
                    case 6:
                        handleActivateMembership();
                        break;
                    case 7:
                        handleRenewMembership();
                        break;
                    case 8:
                        handleViewCurrentlyRentedBooks();
                        break;
                    case 9:
                        handleViewBorrowingHistory();
                        break;
                    case 10:
                        handleManageFines();
                        break;
                    case 11:
                        handleUpdateProfile();
                        break;
                    case 12:
                        currentUser = null;
                        System.out.println("Logged out successfully");
                        return;
                    default:
                        System.out.println("Invalid Choice");
                }
            } catch (GoHomeException e) {
                // Return to Member Menu
            }
        }
    }

    public static void handleViewAllBooks() {
        List<Book> allBooks = bookService.getAllBooks();
        if (allBooks.isEmpty()) {
            System.out.println("No Books Found");
            return;
        }
        UiHelpers.handleBookListInteraction(allBooks);
    }

    public static void handleSearchBooks() {
        UiHelpers.searchBooks();
    }

    public static void handleRequestBook() {
        while (true) {
            System.out.println("\n--- Request a Book ---");
            System.out.println("1. Request directly by ISBN");
            System.out.println("2. Search books and request from results");
            System.out.println("3. Browse catalogue and request a book");
            System.out.println("4. Back");
            System.out.println("0. Go to Home");
            System.out.println("Enter choice:");
            int choice = readInt();
            switch (choice) {
                case 0:
                    goHome();
                    break;
                case 1:
                    while (true) {
                        System.out.println("Enter ISBN (0 to cancel):");
                        String requestIsbn = sc.nextLine().trim();
                        if (requestIsbn.equals("0") || isBackCommand(requestIsbn)) break;
                        if (requestIsbn.isEmpty()) {
                            System.out.println("ISBN cannot be empty.");
                            continue;
                        }
                        Book b = bookService.getBookByIsbn(requestIsbn);
                        if (b == null || b.getStatus() == BookStatus.REMOVED) {
                            System.out.println("Book not found with ISBN: " + requestIsbn);
                            continue;
                        }
                        submitBookRequestByIsbn(requestIsbn);
                        break;
                    }
                    break;
                case 2:
                    UiHelpers.searchBooks();
                    break;
                case 3:
                    List<Book> allBooks = bookService.getAllBooks();
                    if (allBooks.isEmpty()) System.out.println("The catalogue is empty.");
                    else UiHelpers.handleBookListInteraction(allBooks);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Select 1-4.");
            }
        }
    }

    public static void requestBookForSelectedBook(Book book) {
        if (book == null || currentUser == null) {
            submitBookRequest(book);
            return;
        }
        if (currentUser.getRole() != UserRole.MEMBER && operationTargetUser == null) {
            runForTargetMember(() -> submitBookRequest(book));
        } else {
            submitBookRequest(book);
        }
    }

    private static void submitBookRequest(Book book) {
        submitBookRequestByIsbn(book == null ? null : book.getIsbn());
    }

    private static void submitBookRequestByIsbn(String isbn) {
        User requestingMember = getOperationUser();
        Transaction requested;
        try {
            requested = bookTransactionService.requestBookByIsbn(
                    requestingMember == null ? null : requestingMember.getPhone(), isbn, currentUser);
        } catch (IllegalStateException e) {
            List<String> reasons = java.util.Arrays.asList(e.getMessage().split("\\n- "));
            System.out.println("Cannot request this book"
                    + (requestingMember == null ? "" : " for " + requestingMember.getName()) + ":");
            for (String reason : reasons) System.out.println("- " + reason);
            String advice = policyService.getBorrowingResolutionAdvice(reasons);
            if (!advice.isEmpty()) System.out.println("\n" + advice);
            return;
        }
        Book requestedBook =  bookService.getBookByIsbn(isbn);
        if (requested != null) {
            System.out.println("Book request submitted successfully.");
            System.out.println("Book: " + requestedBook.getTitle() + " | ISBN: " + requestedBook.getIsbn());
            System.out.println("Member: " + requestingMember.getName());
            System.out.println("Request status: " + requested.getStatus());
        }
    }

    public static void handleCancelRequest() {
        while (true) {
            System.out.println("Enter ISBN to cancel request (0 to cancel)");
            String cancelIsbn = sc.nextLine().trim();
            if (cancelIsbn.equals("0") || isBackCommand(cancelIsbn)) return;
            if (cancelIsbn.isEmpty()) {
                System.out.println("ISBN cannot be empty.");
                continue;
            }
            User targetMember = getOperationUser();
            try {
                bookTransactionService.cancelRequest(
                        targetMember == null ? null : targetMember.getPhone(), cancelIsbn, currentUser);
                System.out.println("Request cancelled successfully");
                return;
            } catch (IllegalStateException ex) {
                System.out.println("Cancellation failed:");
                for (String reason : ex.getMessage().split("\\R- ")) {
                    System.out.println("- " + reason);
                }
            }
        }
    }

    public static void handleRenewBook() {
        while (true) {
            System.out.println("Enter ISBN to renew (0 to cancel)");
            String renewIsbn = sc.nextLine().trim();
            if (renewIsbn.equals("0") || isBackCommand(renewIsbn)) return;
            if (renewIsbn.isEmpty()) {
                System.out.println("ISBN cannot be empty.");
                continue;
            }
            User targetMember = getOperationUser();
            try {
                if (bookTransactionService.renewBook(
                        targetMember == null ? null : targetMember.getPhone(), renewIsbn, currentUser)) {
                    System.out.println("Book renewed successfully");
                    return;
                } else {
                    System.out.println("Renewal failed: Unable to renew loan. Please contact library staff.");
                }
            } catch (IllegalStateException ex) {
                System.out.println("Renewal failed:");
                for (String reason : ex.getMessage().split("\\R- ")) {
                    System.out.println("- " + reason);
                }
            }
        }
    }

    public static void handleActivateMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership activation failed: A valid logged-in member account is required.");
            return;
        }

        List<MembershipPlan> plans = membershipPlanService.getAllPlans();
        if (plans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : plans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        MembershipPlan selectedPlan = null;
        int planId = -1;
        while (true) {
            System.out.println("Enter Plan ID (0 to cancel)");
            String planInput = sc.nextLine().trim();
            if (planInput.equals("0") || isBackCommand(planInput)) return;
            try {
                planId = Integer.parseInt(planInput);
                selectedPlan = membershipPlanService.findById(planId);
                if (selectedPlan == null) {
                    System.out.println("Invalid Plan ID. Please choose a plan from the list.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid numeric Plan ID.");
            }
        }

        int duration = 0;
        while (true) {
            System.out.println("Enter duration in months (0 to cancel)");
            String durInput = sc.nextLine().trim();
            if (durInput.equals("0") || isBackCommand(durInput)) return;
            try {
                duration = Integer.parseInt(durInput);
                if (duration <= 0) {
                    System.out.println("Duration must be at least 1 month.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number of months.");
            }
        }

        double totalCost = selectedPlan.getAmount() * duration;
        System.out.println("Selected Plan: " + selectedPlan.getPlanName());
        System.out.println("Monthly Price: ₹" + selectedPlan.getAmount());
        System.out.println("Duration: " + duration + " months");
        System.out.println("Total Amount: ₹" + totalCost);

        PaymentMethod membershipMethod = UiHelpers.choosePaymentMethod();
        if (membershipMethod == null) {
            return;
        }

        try {
            membershipService.purchaseMembership(
                    operationUser.getPhone(), planId, duration, membershipMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership activation failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }

        Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
        System.out.println("Payment Status: SUCCESS");
        System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
        if (activeMem != null && activeMem.getEndDate() != null) {
            System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
        }
        System.out.println("Membership activated successfully");
    }

    public static void handleRenewMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership renewal failed: A valid logged-in member account is required.");
            return;
        }

        List<MembershipPlan> renewalPlans = membershipPlanService.getAllPlans();
        if (renewalPlans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : renewalPlans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        MembershipPlan selectedRenewalPlan = null;
        int renewalPlanId = -1;
        while (true) {
            System.out.println("Enter Plan ID (0 to cancel)");
            String planInput = sc.nextLine().trim();
            if (planInput.equals("0") || isBackCommand(planInput)) return;
            try {
                renewalPlanId = Integer.parseInt(planInput);
                selectedRenewalPlan = membershipPlanService.findById(renewalPlanId);
                if (selectedRenewalPlan == null) {
                    System.out.println("Invalid Plan ID. Please choose a plan from the list.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid numeric Plan ID.");
            }
        }

        int renewalDuration = 0;
        while (true) {
            System.out.println("Enter duration in months (0 to cancel)");
            String durInput = sc.nextLine().trim();
            if (durInput.equals("0") || isBackCommand(durInput)) return;
            try {
                renewalDuration = Integer.parseInt(durInput);
                if (renewalDuration <= 0) {
                    System.out.println("Duration must be at least 1 month.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number of months.");
            }
        }

        double renewalTotalCost = selectedRenewalPlan.getAmount() * renewalDuration;
        System.out.println("Selected Plan: " + selectedRenewalPlan.getPlanName());
        System.out.println("Monthly Price: ₹" + selectedRenewalPlan.getAmount());
        System.out.println("Duration: " + renewalDuration + " months");
        System.out.println("Total Amount: ₹" + renewalTotalCost);

        PaymentMethod renewalMethod = UiHelpers.choosePaymentMethod();
        if (renewalMethod == null) {
            return;
        }

        try {
            membershipService.renewMembership(operationUser.getPhone(), renewalPlanId, renewalDuration, renewalMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership renewal failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }

        Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
        System.out.println("Payment Status: SUCCESS");
        System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
        if (activeMem != null && activeMem.getEndDate() != null) {
            System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
        }
        System.out.println("Membership renewed successfully");
    }

    public static void handleViewCurrentlyRentedBooks() {
        List<Transaction> borrowed =
                bookTransactionService.getCurrentlyBorrowedBooks(getOperationUser().getPhone());
        if (borrowed.isEmpty()) {
            System.out.println("You have no currently issued books");
            return;
        }

        for (Transaction t : borrowed) {
            Book borrowedBook = bookService.getBookById(t.getBookId());
            if (borrowedBook != null) {
                System.out.println("ISBN: " + borrowedBook.getIsbn());
                System.out.println("Title: " + borrowedBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleViewBorrowingHistory() {
        List<Transaction> history =
                bookTransactionService.getBorrowingHistory(getOperationUser().getPhone());
        if (history.isEmpty()) {
            System.out.println("No borrowing history found");
            return;
        }

        for (Transaction t : history) {
            Book historyBook = bookService.getBookById(t.getBookId());
            if (historyBook != null) {
                System.out.println("ISBN: " + historyBook.getIsbn());
                System.out.println("Title: " + historyBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Request Date: " + t.getRequestDate());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleManageFines() {
        List<Fine> fineHistory = fineService.getFineHistory(getOperationUser().getPhone(), currentUser);
        if (fineHistory.isEmpty()) {
            System.out.println("No fines found");
            return;
        }

        List<Fine> outstandingFines = fineService.findOutstandingFines(getOperationUser().getPhone());
        for (int i = 0; i < fineHistory.size(); i++) {
            Fine fine = fineHistory.get(i);
            Transaction fineTransaction = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = fineTransaction == null ? null
                    : bookService.getBookById(fineTransaction.getBookId());

            System.out.println((i + 1) + ". ISBN: "
                    + (fineBook == null ? "Unavailable" : fineBook.getIsbn())
                    + ", Type: " + fine.getType()
                    + ", Amount: Rs." + fine.getAmount()
                    + ", Paid: Rs." + fine.getAmountPaid()
                    + ", Remaining: Rs." + fine.getRemainingAmount()
                    + ", Status: " + fine.getStatus());
        }

        if (outstandingFines.isEmpty()) {
            System.out.println("No outstanding fines to pay");
            return;
        }

        Fine activeFine = null;
        while (true) {
            System.out.println("Enter the ISBN for the fine you want to pay (0 to cancel)");
            String fineIsbn = sc.nextLine().trim();
            if (fineIsbn.equals("0") || isBackCommand(fineIsbn)) return;
            if (fineIsbn.isEmpty()) {
                System.out.println("ISBN cannot be empty");
                continue;
            }

            for (Fine fine : outstandingFines) {
                Transaction t = bookTransactionService.findTransactionById(fine.getTransactionId());
                Book fineBook = t == null ? null : bookService.getBookById(t.getBookId());
                if (fineBook != null && fineBook.getIsbn().equalsIgnoreCase(fineIsbn)) {
                    activeFine = fine;
                    break;
                }
            }

            if (activeFine == null) {
                System.out.println("No outstanding fine found for ISBN: " + fineIsbn);
                continue;
            }
            break;
        }

        double amount = 0;
        while (true) {
            System.out.println("Remaining amount: Rs." + activeFine.getRemainingAmount());
            System.out.println("Enter amount to pay (0 to cancel)");
            String amountInput = sc.nextLine().trim();
            if (amountInput.equals("0") || isBackCommand(amountInput)) return;
            try {
                amount = Double.parseDouble(amountInput);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid payment amount: Enter a numeric amount, for example 100 or 100.50.");
                continue;
            }
            if (!Double.isFinite(amount)) {
                System.out.println("Invalid payment amount: Enter a valid finite amount.");
                continue;
            }
            if (amount <= 0) {
                System.out.println("Invalid payment amount: Amount must be greater than zero.");
                continue;
            }
            if (amount > activeFine.getRemainingAmount()) {
                System.out.println("Invalid payment amount: Rs." + amount + " exceeds the remaining fine balance of Rs." + activeFine.getRemainingAmount() + ".");
                continue;
            }
            break;
        }

        PaymentMethod fineMethod = UiHelpers.choosePaymentMethod();
        if (fineMethod == null) {
            System.out.println("Payment method not found");
            return;
        }

        Payment payment = paymentService.payFine(getOperationUser().getPhone(),
                    activeFine.getFineId(), amount, fineMethod);

        if (payment != null && payment.getStatus() == PaymentStatus.SUCCESS) {
            System.out.println("Fine payment successful");
        } else if (payment != null && payment.getStatus() == PaymentStatus.FAILED) {
            System.out.println("Fine payment failed: The payment gateway did not complete the transaction. Please verify your fine balance before trying again.");
        }
    }

    public static void handleUpdateProfile() {
        System.out.println("1.Update Name");
        System.out.println("2.Update Email");
        System.out.println("3.Update Phone");
        System.out.println("4.Change Password");
        System.out.println("5.Back");
        System.out.println("0.Go to Home");
        System.out.println("Enter choice");
        int profileChoice = readInt();

        switch (profileChoice) {
            case 0:
                goHome();
                break;
            case 1:
                while (true) {
                    System.out.println("Enter new name (0 to cancel)");
                    String newName = sc.nextLine().trim();
                    if (newName.equals("0") || isBackCommand(newName)) break;
                    String err = userService.validateUpdateName(newName, currentUser.getName());
                    if (err != null) {
                        System.out.println(err);
                        continue;
                    }
                    if (userService.updateNameForPhone(newName, getOperationUser().getPhone())) {
                        System.out.println("Name updated successfully");
                    } else {
                        System.out.println("User not found.");
                    }
                    break;
                }
                break;

            case 2:
                while (true) {
                    System.out.println("Enter new email (0 to cancel)");
                    String newEmail = sc.nextLine().trim();
                    if (newEmail.equals("0") || isBackCommand(newEmail)) break;
                    String err = userService.validateUpdateEmail(newEmail, currentUser.getEmail());
                    if (err != null) {
                        System.out.println(err);
                        continue;
                    }
                    if (userService.changeEmailForPhone(newEmail, getOperationUser().getPhone())) {
                        System.out.println("Email updated successfully");
                    } else {
                        System.out.println("Unable to update email: User not found.");
                    }
                    break;
                }
                break;

            case 3:
                while (true) {
                    System.out.println("Enter new phone number (0 to cancel)");
                    String newPhone = sc.nextLine().trim();
                    if (newPhone.equals("0") || isBackCommand(newPhone)) break;
                    String err = userService.validateUpdatePhone(newPhone, currentUser.getPhone());
                    if (err != null) {
                        System.out.println(err);
                        continue;
                    }
                    if (userService.changePhoneForPhone(currentUser.getPhone(), newPhone)) {
                        System.out.println("Phone updated successfully");
                    } else {
                        System.out.println("Unable to update phone: User not found.");
                    }
                    break;
                }
                break;

            case 4:
                while (true) {
                    System.out.println("Enter current password (0 to cancel)");
                    String oldPassword = sc.nextLine();
                    if (oldPassword.equals("0") || isBackCommand(oldPassword)) break;
                    if (!AuthService.verifyPassword(oldPassword, currentUser.getPasswordHash())) {
                        System.out.println("Password change failed: Current password is incorrect.");
                        continue;
                    }

                    boolean backToOld = false;
                    while (true) {
                        System.out.println("Enter new password (0 to go back)");
                        String newPassword = sc.nextLine();
                        if (newPassword.equals("0") || isBackCommand(newPassword)) {
                            backToOld = true;
                            break;
                        }
                        if (!isValidPassword(newPassword)) {
                            System.out.println("Password must be at least 8 characters and include an uppercase letter, a number, and a special character.");
                            continue;
                        }
                        if (AuthService.verifyPassword(newPassword, currentUser.getPasswordHash())) {
                            System.out.println("Password change failed: New password cannot be the same as your current password.");
                            continue;
                        }
                        if (userService.changePasswordForPhone(
                                getOperationUser().getPhone(), oldPassword, newPassword)) {
                            System.out.println("Password changed successfully");
                        } else {
                            System.out.println("Password change failed: User not found.");
                        }
                        break;
                    }
                    if (!backToOld) break;
                }
                break;

            case 5:
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
    private static boolean isValidPassword(String password) {
        return password != null && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public static void runForTargetMember(Runnable operation) {
        if (currentUser == null || operation == null) {
            System.out.println("Please log in before performing this operation.");
            return;
        }
        while (true) {
            System.out.println("Enter the member's phone number or email (0 to cancel):");
            String identifier = sc.nextLine().trim();
            if (identifier.isEmpty() || identifier.equals("0") || isBackCommand(identifier)) return;

            User target = userService.findByPhone(identifier);
            if (target == null && identifier.contains("@")) {
                target = userService.findByEmail(identifier);
            }
            if (target == null) {
                System.out.println("No account found for that phone number or email.");
                continue;
            }
            if (target.getRole() != UserRole.MEMBER) {
                System.out.println("This operation is for member accounts only. The selected account is " + target.getRole() + ".");
                continue;
            }
            if (target.getStatus() != UserStatus.ACTIVE) {
                System.out.println("This member account is not active. Activate the account before continuing.");
                continue;
            }

            operationTargetUser = target;
            try {
                System.out.println("Selected member: " + target.getName() + " | Phone: " + target.getPhone() + " | Email: " + target.getEmail());
                operation.run();
                return;
            } finally {
                operationTargetUser = null;
            }
        }
    }
    private static User operationTargetUser;

    private static User getOperationUser() {

        return operationTargetUser != null ? operationTargetUser : currentUser;
    }
}
