package ui;

import enums.PaymentMethod;
import enums.UserRole;
import enums.UserStatus;
import model.Book;
import model.Fine;
import model.MembershipPlan;
import model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import repository.SyntheticData;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class ValidationAndRetryTest {

    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        SyntheticData data = new SyntheticData(Main.userRepository, Main.membershipPlanRepository, Main.bookService,
                Main.authorRepository, Main.genreRepository, Main.membershipRepository, Main.transactionRepository,
                Main.fineRepository, Main.paymentRepository, Main.auditLogRepository, Main.categoryRepository,
                Main.bookCopyRepository);
        data.syntheticData();
    }

    @AfterEach
    void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
        Main.currentUser = null;
        Main.sc = new Scanner(System.in);
    }

    private void provideInput(String input) {
        Main.sc = new Scanner(new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void test1_RegistrationRetriesOnInvalidInputsWithoutLosingProgress() {
        // Registration flow:
        // Choice 2: Register
        // Name: "" -> "Alice Wonderland"
        // Phone: "123" -> "9870000001" (existing) -> "9998887771" (valid)
        // Email: "bademail" -> "alice@example.com"
        // Age: "abc" -> "200" -> "28"
        // Gender: "INVALID" -> "FEMALE"
        // Password: "weak" -> "SecurePass1!"
        // Confirm Password: "MismatchPass1!" -> "SecurePass1!"
        String input = String.join("\n",
                "2",
                "",
                "Alice Wonderland",
                "123",
                "9870000001",
                "9998887771",
                "bademail",
                "alice@example.com",
                "abc",
                "200",
                "28",
                "INVALID",
                "FEMALE",
                "weak",
                "SecurePass1!",
                "MismatchPass1!",
                "SecurePass1!"
        ) + "\n";

        provideInput(input);
        Member.member();

        String output = outContent.toString();
        assertTrue(output.contains("Registration failed: Name cannot be empty."));
        assertTrue(output.contains("Registration failed: Phone number must be a valid 10-digit number."));
        assertTrue(output.contains("already exists"));
        assertTrue(output.contains("Registration failed: Invalid email format."));
        assertTrue(output.contains("Registration failed: Enter a valid age."));
        assertTrue(output.contains("Registration failed: Age must be between 1 and 120."));
        assertTrue(output.contains("Registration failed: Choose one of the listed gender options."));
        assertTrue(output.contains("Registration failed: Password must be at least 8 characters"));
        assertTrue(output.contains("Registration failed: Passwords do not match."));
        assertTrue(output.contains("Registration successful."));

        User created = Main.userService.findByPhone("9998887771");
        assertNotNull(created);
        assertEquals("Alice Wonderland", created.getName());
        assertEquals("alice@example.com", created.getEmail());
    }

    @Test
    void test2_RegistrationBackNavigationRetainsProgress() {
        // Choice 2: Register
        // Name: "Bob Builder"
        // Phone: "9998887772"
        // Email: "back" (returns to step 2: phone)
        // Phone: "9998887773" (new phone)
        // Email: "bob@example.com"
        // Age: 30
        // Gender: MALE
        // Password: "SecurePass1!"
        // Confirm: "SecurePass1!"
        String input = String.join("\n",
                "2",
                "Bob Builder",
                "9998887772",
                "back",
                "9998887773",
                "bob@example.com",
                "30",
                "MALE",
                "SecurePass1!",
                "SecurePass1!"
        ) + "\n";

        provideInput(input);
        Member.member();

        String output = outContent.toString();
        assertTrue(output.contains("Registration successful."));
        User created = Main.userService.findByPhone("9998887773");
        assertNotNull(created);
        assertEquals("Bob Builder", created.getName());
        assertNull(Main.userService.findByPhone("9998887772"));
    }

    @Test
    void test3_MemberLoginRetriesIncorrectPassword() {
        // Choice 1: Login
        // Mobile: "9870000001"
        // Password: "WrongPassword" (fails, prompts password again)
        // Password: "MemberPass123!" (correct)
        // In memberMenu: 12 (Logout)
        String input = String.join("\n",
                "1",
                "9870000001",
                "WrongPassword",
                "MemberPass123!",
                "12"
        ) + "\n";

        provideInput(input);
        Member.member();

        String output = outContent.toString();
        assertTrue(output.contains("Login Failed: Invalid credentials."));
        assertTrue(output.contains("Login Success"));
        assertTrue(output.contains("Logged out successfully"));
    }

    @Test
    void test4_StaffLoginRetriesOnInvalidCredentials() {
        // Identifier: "8888888888" (librarian)
        // Password: "WrongPassword" -> Invalid credentials (stays on password prompt)
        // Password: "lib123" -> Login successful
        String input = String.join("\n",
                "8888888888",
                "WrongPassword",
                "lib123"
        ) + "\n";

        provideInput(input);
        boolean loggedIn = Main.staffLogin(UserRole.LIBRARIAN);

        assertTrue(loggedIn);
        String output = outContent.toString();
        assertTrue(output.contains("Invalid credentials"));
        assertTrue(output.contains("Login successful"));
        assertNotNull(Main.currentUser);
        assertEquals(UserRole.LIBRARIAN, Main.currentUser.getRole());
    }

    @Test
    void test5_LibrarianAddBookEarlyValidationAndRetry() {
        User librarian = Main.userService.findByPhone("8888888888");
        Main.currentUser = librarian;

        // 12: Add Book
        // ISBN: "" -> error -> "978-9-99-888777-1"
        // Title: "" -> error -> "Clean Architecture Design"
        // Author: "" -> error -> "Robert C. Martin"
        // Genre: "Software, Architecture"
        // Publisher: "" -> error -> "Pearson"
        // Year: "invalid_year" -> error -> "2023"
        // Description: "Classic book"
        // Copies: "-5" -> error -> "3"
        // 25: Logout
        String input = String.join("\n",
                "12",
                "",
                "978-9-99-888777-1",
                "",
                "Clean Architecture Design",
                "",
                "Robert C. Martin",
                "Software, Architecture",
                "",
                "Pearson",
                "invalid_year",
                "2023",
                "Classic book",
                "-5",
                "3",
                "25"
        ) + "\n";

        provideInput(input);
        Librarian.librarian();

        String output = outContent.toString();
        assertTrue(output.contains("ISBN cannot be empty."));
        assertTrue(output.contains("Title cannot be empty."));
        assertTrue(output.contains("Author cannot be empty."));
        assertTrue(output.contains("Publisher cannot be empty."));
        assertTrue(output.contains("Publication year is invalid."));
        assertTrue(output.contains("Number of copies must be at least 1."));
        assertTrue(output.contains("Book added successfully"));

        Book createdBook = Main.bookService.getBookByIsbn("978-9-99-888777-1");
        assertNotNull(createdBook);
        assertEquals("Clean Architecture Design", createdBook.getTitle());
    }

    @Test
    void test6_ActivateMembershipValidatesPlanBeforeDurationAndPayment() {
        User member = new User("Fresh Member", "fresh@library.com", "9870000099",
                service.AuthService.hashPassword("MemberPass123!"), UserRole.MEMBER, UserStatus.ACTIVE, 25, "FEMALE");
        Main.userRepository.save(member);
        Main.currentUser = member;

        // 6: Activate Membership
        // Plan ID: 9999 (invalid) -> error -> 1 (Standard Plan)
        // Duration: -2 (invalid) -> error -> 2 (valid)
        // Payment method: 1 (UPI)
        // 12: Logout
        String input = String.join("\n",
                "6",
                "9999",
                "1",
                "-2",
                "2",
                "1",
                "12"
        ) + "\n";

        provideInput(input);
        Member.memberMenu();

        String output = outContent.toString();
        assertTrue(output.contains("Invalid Plan ID. Please choose a plan from the list."));
        assertTrue(output.contains("Duration must be at least 1 month."));
        assertTrue(output.contains("Membership activated successfully"));
    }

    @Test
    void test7_AdminCreatePlanValidatesFieldsWithRetry() {
        User admin = Main.userService.findByPhone("9999999999");
        Main.currentUser = admin;

        // 27: Manage Membership Plans -> 2: Create Plan
        // Name: "" -> error -> "Enterprise Platinum"
        // Amount: "-100" -> error -> "1200.0"
        // Max books: "0" -> error -> "15"
        // Loan days: "-2" -> error -> "45"
        // Fine per day: "-5" -> error -> "10.0"
        // Lost charge: "-50" -> error -> "800.0"
        // Damaged charge: "-20" -> error -> "400.0"
        // 29: Logout
        String input = String.join("\n",
                "27",
                "2",
                "",
                "Enterprise Platinum",
                "-100",
                "1200.0",
                "0",
                "15",
                "-2",
                "45",
                "-5",
                "10.0",
                "-50",
                "800.0",
                "-20",
                "400.0",
                "29"
        ) + "\n";

        provideInput(input);
        Admin.admin();

        String output = outContent.toString();
        assertTrue(output.contains("Plan name cannot be empty."));
        assertTrue(output.contains("Plan amount must be a positive number."));
        assertTrue(output.contains("Maximum books must be at least 1."));
        assertTrue(output.contains("Loan period in days must be at least 1."));
        assertTrue(output.contains("Fine per day charge cannot be negative."));
        assertTrue(output.contains("Lost book charge charge cannot be negative."));
        assertTrue(output.contains("Damaged book charge charge cannot be negative."));
        assertTrue(output.contains("Plan created successfully: Enterprise Platinum"));

        List<MembershipPlan> allPlans = Main.membershipPlanService.getAllPlans();
        boolean found = allPlans.stream().anyMatch(p -> p.getPlanName().equals("Enterprise Platinum"));
        assertTrue(found);
    }

    @Test
    void test8_AdminAddLibrarianValidatesFieldsWithRetry() {
        User admin = Main.userService.findByPhone("9999999999");
        Main.currentUser = admin;

        // 25: Manage Users -> 2: Add Librarian
        // Name: "" -> error -> "David Librarian"
        // Email: "invalid_email" -> error -> "david@library.com"
        // Phone: "123" -> error -> "8880000002"
        // Password: "short" -> error -> "SecureStaff1!"
        // 29: Logout
        String input = String.join("\n",
                "25",
                "2",
                "",
                "David Librarian",
                "invalid_email",
                "david@library.com",
                "123",
                "8880000002",
                "short",
                "SecureStaff1!",
                "29"
        ) + "\n";

        provideInput(input);
        Admin.admin();

        String output = outContent.toString();
        assertTrue(output.contains("Name cannot be empty."));
        assertTrue(output.contains("Invalid email format."));
        assertTrue(output.contains("Phone number must be a valid 10-digit number."));
        assertTrue(output.contains("Password must be at least 8 characters long."));
        assertTrue(output.contains("User created"));

        User lib = Main.userService.findByPhone("8880000002");
        assertNotNull(lib);
        assertEquals("David Librarian", lib.getName());
        assertEquals(UserRole.LIBRARIAN, lib.getRole());
    }

    @Test
    void test9_ProcessReturnValidatesMemberAndBookEarlyWithRetry() {
        User librarian = Main.userService.findByPhone("8888888888");
        Main.currentUser = librarian;

        // 17: Process Return
        // Member phone: "0000000000" (not found) -> error -> "9870000001"
        // ISBN: "0000000000" (book not found) -> error -> "978-0132350884" (valid loan)
        // Condition: 1 (Normal)
        // Confirm: y
        // 25: Logout
        String input = String.join("\n",
                "17",
                "0000000000",
                "9870000001",
                "0000000000",
                "978-0132350884",
                "1",
                "y",
                "25"
        ) + "\n";

        provideInput(input);
        Librarian.librarian();

        String output = outContent.toString();
        assertTrue(output.contains("Member not found."));
        assertTrue(output.contains("Return processed."));
    }
}
