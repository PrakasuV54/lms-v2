package ui;

import enums.PaymentMethod;
import enums.PaymentStatus;
import enums.TransactionStatus;
import enums.UserRole;
import enums.UserStatus;
import model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import service.AuthService;
import java.util.*;

public class Member extends Main {



    public static void member() {
        System.out.println("1.Login or 2.Register or 3.Exit");
        int loginChoice = readInt();

        switch (loginChoice) {
            case 1:
                System.out.println("Enter Mobile or Email");
                String identifier = sc.nextLine().trim();
                System.out.println("Enter Password");
                String loginPassword = sc.nextLine();

                if (identifier.isEmpty() || loginPassword.isEmpty()) {
                    System.out.println("Login Failed: Phone/Email and password cannot be empty. Please enter your credentials.");
                    break;
                }

                User user = authService.login(identifier, loginPassword);
                if (user != null) {
                    if (user.getRole() != UserRole.MEMBER) {
                        currentUser = null;
                        System.out.println("Login Failed: This account is registered as " + user.getRole() + ". Please log in via the Librarian or Admin menu.");
                        break;
                    }
                    if (user.getStatus() != UserStatus.ACTIVE) {
                        currentUser = null;
                        System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                        break;
                    }
                    currentUser = user;
                    System.out.println("Login Success");
                    memberMenu();
                } else {
                    
                    User existing = userService.findByPhone(identifier);
                    if (existing == null) existing = userService.findByEmail(identifier);
                    if (existing != null && existing.getStatus() == UserStatus.INACTIVE) {
                        System.out.println("Login Failed: Your account has been deactivated. Please contact the librarian for reactivation.");
                    } else {
                        System.out.println("Login Failed: Invalid credentials. Please check your phone/email and password, or register for a new account.");
                    }
                }
                break;

            case 2:
                System.out.println("Enter your name");
                String name = sc.nextLine().trim();
                if (name.isEmpty()) {
                    System.out.println("Registration failed: Name cannot be empty.");
                    break;
                }

                System.out.println("Enter your phone number");
                String phone = sc.nextLine().trim();
                if (!phone.matches("\\d{10}")) {
                    System.out.println("Registration failed: Phone number must be a valid 10-digit number.");
                    break;
                }
                if (userService.phoneExists(phone)) {
                    System.out.println("Registration failed: An account with phone number " + phone + " already exists. Please log in or use a different phone number.");
                    break;
                }

                System.out.println("Enter your email");
                String email = sc.nextLine().trim();
                if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    System.out.println("Registration failed: Invalid email format. Please provide a valid email address (e.g. user@example.com).");
                    break;
                }
                if (userService.emailExists(email)) {
                    System.out.println("Registration failed: An account with email address " + email + " already exists. Please log in or use a different email address.");
                    break;
                }

                System.out.println("Enter your age");
                int age;
                try { age = Integer.parseInt(sc.nextLine().trim()); }
                catch (NumberFormatException ex) { System.out.println("Registration failed: Enter a valid age."); break; }
                if (age < 1 || age > 120) { System.out.println("Registration failed: Age must be between 1 and 120."); break; }

                System.out.println("Enter your gender (MALE/FEMALE/NON_BINARY/OTHER/PREFER_NOT_TO_SAY)");
                String gender = sc.nextLine().trim().toUpperCase();
                if (!Set.of("MALE", "FEMALE", "NON_BINARY", "OTHER", "PREFER_NOT_TO_SAY").contains(gender)) {
                    System.out.println("Registration failed: Choose one of the listed gender options."); break;
                }

                System.out.println("Enter your password");
                String registerPassword = sc.nextLine();


                System.out.println("Enter your password again");
                String confirmPassword = sc.nextLine();
                if (!registerPassword.equals(confirmPassword)) {
                    System.out.println("Registration failed: Passwords do not match.");
                    break;
                }
                String regReason = userService.getRegistrationFailureReason(name, email, phone, confirmPassword);
                if(regReason!=null){
                    System.out.println("Registration failed: " + (regReason != null ? regReason : "Unable to create user account. Please check your details."));
                    break;
                }
                authService.register(name, email, phone, confirmPassword);
                System.out.println("Registration successful. Your account and profile details have been saved.");
                break;

            case 3:
                return;

            default:
                System.out.println("Invalid Input");
        }
    }

    public static void memberMenu() {
        while (true) {
            System.out.println("\n1.View All Books");
            System.out.println("2.Search Books");
            System.out.println("3.Request Book");
            System.out.println("4.Cancel Request");
            System.out.println("5.Renew Book");
            System.out.println("6.Activate Membership");
            System.out.println("7.Renew Membership");
            System.out.println("8.View Currently Rented Books");
            System.out.println("9.View Borrowing History");
            System.out.println("10.Manage Fines");
            System.out.println("11.Update Profile");
            System.out.println("12.Logout");
            System.out.println("Enter Your Choice");

            int choice = readInt();

            switch (choice) {
                case 1:
                    handleViewAllBooks();
                    break;
                case 2:
                    handleSearchBooks();
                    break;
                case 3:
                    handleRequestBook();
                    break;
                case 4:
                    handleCancelRequest();
                    break;
                case 5:
                    handleRenewBook();
                    break;
                case 6:
                    handleActivateMembership();
                    break;
                case 7:
                    handleRenewMembership();
                    break;
                case 8:
                    handleViewCurrentlyRentedBooks();
                    break;
                case 9:
                    handleViewBorrowingHistory();
                    break;
                case 10:
                    handleManageFines();
                    break;
                case 11:
                    handleUpdateProfile();
                    break;
                case 12:
                    currentUser = null;
                    System.out.println("Logged out successfully");
                    return;
                default:
                    System.out.println("Invalid Choice");
            }
        }
    }

    public static void handleViewAllBooks() {
        List<Book> allBooks = bookService.getAllBooks();
        if (allBooks.isEmpty()) {
            System.out.println("No Books Found");
            return;
        }
        UiHelpers.handleBookListInteraction(allBooks);
    }

    public static void handleSearchBooks() {
        UiHelpers.searchBooks();
    }

    public static void handleRequestBook() {
        while (true) {
            System.out.println("\n--- Request a Book ---");
            System.out.println("1. Request directly by ISBN");
            System.out.println("2. Search books and request from results");
            System.out.println("3. Browse catalogue and request a book");
            System.out.println("4. Back");
            System.out.println("Enter choice:");
            int choice = readInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter ISBN (0 to cancel):");
                    String requestIsbn = sc.nextLine().trim();
                    if (requestIsbn.equals("0")) break;
                    submitBookRequestByIsbn(requestIsbn);
                    break;
                case 2:
                    UiHelpers.searchBooks();
                    break;
                case 3:
                    List<Book> allBooks = bookService.getAllBooks();
                    if (allBooks.isEmpty()) System.out.println("The catalogue is empty.");
                    else UiHelpers.handleBookListInteraction(allBooks);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Select 1-4.");
            }
        }
    }

    public static void requestBookForSelectedBook(Book book) {
        if (book == null || currentUser == null) {
            submitBookRequest(book);
            return;
        }
        if (currentUser.getRole() != UserRole.MEMBER && operationTargetUser == null) {
            runForTargetMember(() -> submitBookRequest(book));
        } else {
            submitBookRequest(book);
        }
    }

    private static void submitBookRequest(Book book) {
        submitBookRequestByIsbn(book == null ? null : book.getIsbn());
    }

    private static void submitBookRequestByIsbn(String isbn) {
        User requestingMember = getOperationUser();
        Transaction requested;
        try {
            requested = bookTransactionService.requestBookByIsbn(
                    requestingMember == null ? null : requestingMember.getPhone(), isbn, currentUser);
        } catch (IllegalStateException e) {
            List<String> reasons = java.util.Arrays.asList(e.getMessage().split("\\n- "));
            System.out.println("Cannot request this book"
                    + (requestingMember == null ? "" : " for " + requestingMember.getName()) + ":");
            for (String reason : reasons) System.out.println("- " + reason);
            String advice = policyService.getBorrowingResolutionAdvice(reasons);
            if (!advice.isEmpty()) System.out.println("\n" + advice);
            return;
        }
        Book requestedBook =  bookService.getBookByIsbn(isbn);
        if (requested != null) {
            System.out.println("Book request submitted successfully.");
            System.out.println("Book: " + requestedBook.getTitle() + " | ISBN: " + requestedBook.getIsbn());
            System.out.println("Member: " + requestingMember.getName());
            System.out.println("Request status: " + requested.getStatus());
        }
    }

    public static void handleCancelRequest() {
        System.out.println("Enter ISBN to cancel request");
        String cancelIsbn = sc.nextLine().trim();
        User targetMember = getOperationUser();
        try {
            bookTransactionService.cancelRequest(
                    targetMember == null ? null : targetMember.getPhone(), cancelIsbn, currentUser);
            System.out.println("Request cancelled successfully");
        } catch (IllegalStateException ex) {
            System.out.println("Cancellation failed:");
            for (String reason : ex.getMessage().split("\\R- ")) {
                System.out.println("- " + reason);
            }
        }
    }

    public static void handleRenewBook() {
        System.out.println("Enter ISBN to renew");
        String renewIsbn = sc.nextLine().trim();
        User targetMember = getOperationUser();
        try {
            if (bookTransactionService.renewBook(
                    targetMember == null ? null : targetMember.getPhone(), renewIsbn, currentUser)) {
                System.out.println("Book renewed successfully");
            } else {
                System.out.println("Renewal failed: Unable to renew loan. Please contact library staff.");
            }
        } catch (IllegalStateException ex) {
            System.out.println("Renewal failed:");
            for (String reason : ex.getMessage().split("\\R- ")) {
                System.out.println("- " + reason);
            }
        }
    }

    public static void handleActivateMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership activation failed: A valid logged-in member account is required.");
            return;
        }

        List<MembershipPlan> plans = membershipPlanService.getAllPlans();
        if (plans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : plans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        System.out.println("Enter Plan ID");
        int planId = readInt();
        MembershipPlan selectedPlan = membershipPlanService.findById(planId);
        System.out.println("Enter duration in months");
        int duration = readInt();

        if (selectedPlan != null) {
            double totalCost = selectedPlan.getAmount() * duration;
            System.out.println("Selected Plan: " + selectedPlan.getPlanName());
            System.out.println("Monthly Price: ₹" + selectedPlan.getAmount());
            System.out.println("Duration: " + duration + " months");
            System.out.println("Total Amount: ₹" + totalCost);
        }

        PaymentMethod membershipMethod = UiHelpers.choosePaymentMethod();
        if (membershipMethod == null) {
            return;
        }

        try {
            membershipService.purchaseMembership(
                    operationUser.getPhone(), planId, duration, membershipMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership activation failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }


            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            System.out.println("Membership activated successfully");

    }

    public static void handleRenewMembership() {
        User operationUser = getOperationUser();
        if (operationUser == null) {
            System.out.println("Membership renewal failed: A valid logged-in member account is required.");
            return;
        }

        List<MembershipPlan> renewalPlans = membershipPlanService.getAllPlans();
        if (renewalPlans.isEmpty()) {
            System.out.println("No membership plans available");
            return;
        }

        for (MembershipPlan plan : renewalPlans) {
            System.out.println(plan.getPlanId() + ". " + plan.getPlanName()
                    + " - Rs." + plan.getAmount());
        }

        System.out.println("Enter Plan ID");
        int renewalPlanId = readInt();
        MembershipPlan selectedRenewalPlan = membershipPlanService.findById(renewalPlanId);

        System.out.println("Enter duration in months");
        int renewalDuration = readInt();

        if (selectedRenewalPlan != null) {
            double renewalTotalCost = selectedRenewalPlan.getAmount() * renewalDuration;
            System.out.println("Selected Plan: " + selectedRenewalPlan.getPlanName());
            System.out.println("Monthly Price: ₹" + selectedRenewalPlan.getAmount());
            System.out.println("Duration: " + renewalDuration + " months");
            System.out.println("Total Amount: ₹" + renewalTotalCost);
        }

        PaymentMethod renewalMethod = UiHelpers.choosePaymentMethod();
        if (renewalMethod == null) {
            return;
        }


        try {
            membershipService.renewMembership(operationUser.getPhone(), renewalPlanId, renewalDuration, renewalMethod);
        } catch (IllegalArgumentException ex) {
            System.out.println("Membership renewal failed:");
            for (String reason : ex.getMessage().split("\\R")) {
                if (!reason.isBlank()) {
                    System.out.println("- " + reason);
                }
            }
            return;
        }

            Membership activeMem = membershipService.getActiveMembership(operationUser.getPhone());
            System.out.println("Payment Status: SUCCESS");
            System.out.println("Membership Status: " + (activeMem != null ? activeMem.getStatus() : "Unable to reload membership status"));
            if (activeMem != null && activeMem.getEndDate() != null) {
                System.out.println("Membership Expiry Date: " + activeMem.getEndDate());
            }
            System.out.println("Membership renewed successfully");

    }

        public static void handleViewCurrentlyRentedBooks() {
        List<Transaction> borrowed =
                bookTransactionService.getCurrentlyBorrowedBooks(getOperationUser().getPhone());
        if (borrowed.isEmpty()) {
            System.out.println("You have no currently issued books");
            return;
        }

        for (Transaction t : borrowed) {
            Book borrowedBook = bookService.getBookById(t.getBookId());
            if (borrowedBook != null) {
                System.out.println("ISBN: " + borrowedBook.getIsbn());
                System.out.println("Title: " + borrowedBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleViewBorrowingHistory() {
        List<Transaction> history =
                bookTransactionService.getBorrowingHistory(getOperationUser().getPhone());
        if (history.isEmpty()) {
            System.out.println("No borrowing history found");
            return;
        }

        for (Transaction t : history) {
            Book historyBook = bookService.getBookById(t.getBookId());
            if (historyBook != null) {
                System.out.println("ISBN: " + historyBook.getIsbn());
                System.out.println("Title: " + historyBook.getTitle());
                System.out.println("Status: " + t.getStatus());
                System.out.println("Request Date: " + t.getRequestDate());
                System.out.println("Due Date: " + t.getDueDate());
                System.out.println("--------------------");
            }
        }
    }

    public static void handleManageFines() {
        List<Fine> fineHistory = fineService.getFineHistory(getOperationUser().getPhone(), currentUser);
        if (fineHistory.isEmpty()) {
            System.out.println("No fines found");
            return;
        }

        List<Fine> outstandingFines = fineService.findOutstandingFines(getOperationUser().getPhone());
        for (int i = 0; i < fineHistory.size(); i++) {
            Fine fine = fineHistory.get(i);
            Transaction fineTransaction = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = fineTransaction == null ? null
                    : bookService.getBookById(fineTransaction.getBookId());

            System.out.println((i + 1) + ". ISBN: "
                    + (fineBook == null ? "Unavailable" : fineBook.getIsbn())
                    + ", Type: " + fine.getType()
                    + ", Amount: Rs." + fine.getAmount()
                    + ", Paid: Rs." + fine.getAmountPaid()
                    + ", Remaining: Rs." + fine.getRemainingAmount()
                    + ", Status: " + fine.getStatus());
        }

        if (outstandingFines.isEmpty()) {
            System.out.println("No outstanding fines to pay");
            return;
        }

        System.out.println("Enter the ISBN for the fine you want to pay");
        String fineIsbn = sc.nextLine().trim();
        if (fineIsbn.isEmpty()) {
            System.out.println("ISBN cannot be empty");
            return;
        }

        Fine activeFine= null;
        for (Fine fine : outstandingFines) {
            Transaction t = bookTransactionService.findTransactionById(fine.getTransactionId());
            Book fineBook = t == null ? null : bookService.getBookById(t.getBookId());
            if (fineBook != null && fineBook.getIsbn().equalsIgnoreCase(fineIsbn)) {
                activeFine=fine;
                break;
            }
        }

        if (activeFine==null) {
            System.out.println("No outstanding fine found for ISBN: " + fineIsbn);
            return;
        }



        System.out.println("Remaining amount: Rs." + activeFine.getRemainingAmount());
        System.out.println("Enter amount to pay");
        String amountInput = sc.nextLine().trim();
        double amount;
        try {
            amount = Double.parseDouble(amountInput);
        } catch (NumberFormatException ex) {
            System.out.println("Invalid payment amount: Enter a numeric amount, for example 100 or 100.50.");
            return;
        }
        if (!Double.isFinite(amount)) {
            System.out.println("Invalid payment amount: Enter a valid finite amount.");
            return;
        }
        if (amount <= 0) {
            System.out.println("Invalid payment amount: Amount must be greater than zero.");
            return;
        }
        if (amount > activeFine.getRemainingAmount()) {
            System.out.println("Invalid payment amount: Rs." + amount + " exceeds the remaining fine balance of Rs." + activeFine.getRemainingAmount() + ".");
            return;
        }

        PaymentMethod fineMethod = UiHelpers.choosePaymentMethod();
        if (fineMethod == null) {
            System.out.println("Payment method not found");
            return;
        }

        Payment payment = paymentService.payFine(getOperationUser().getPhone(),
                    activeFine.getFineId(), amount, fineMethod);

        if (payment != null && payment.getStatus() == PaymentStatus.SUCCESS) {
            System.out.println("Fine payment successful");
        } else if (payment != null && payment.getStatus() == PaymentStatus.FAILED) {
            System.out.println("Fine payment failed: The payment gateway did not complete the transaction. Please verify your fine balance before trying again.");
        }
    }

    public static void handleUpdateProfile() {
        System.out.println("1.Update Name");
        System.out.println("2.Update Email");
        System.out.println("3.Update Phone");
        System.out.println("4.Change Password");
        System.out.println("5.Back");
        System.out.println("Enter choice");
        int profileChoice = readInt();

        switch (profileChoice) {
            case 1:
                System.out.println("Enter new name");
                String newName = sc.nextLine().trim();
                if (newName.isEmpty()) {
                    System.out.println("Name cannot be empty");
                } else if (newName.equals(currentUser.getName())) {
                    System.out.println("Unable to update name: New name is identical to your current name.");
                } else if (userService.updateNameForPhone(newName, getOperationUser().getPhone())) {
                    System.out.println("Name updated successfully");
                } else {
                    System.out.println("User not found.");
                }
                break;

            case 2:
                System.out.println("Enter new email");
                String newEmail = sc.nextLine().trim();
                if (!newEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    System.out.println("Invalid email format. Please enter a valid email address (e.g., user@example.com).");
                } else if (newEmail.equalsIgnoreCase(currentUser.getEmail())) {
                    System.out.println("Unable to update email: New email is identical to your current email.");
                } else if (userService.findByEmail(newEmail) != null) {
                    System.out.println("Unable to update email: The email address '" + newEmail + "' is already registered to another account.");
                } else if (userService.changeEmailForPhone(newEmail, getOperationUser().getPhone())) {
                    System.out.println("Email updated successfully");
                } else {
                    System.out.println("Unable to update email: User not found.");
                }
                break;

            case 3:
                System.out.println("Enter new phone number");
                String newPhone = sc.nextLine().trim();
                if (!newPhone.matches("\\d{10}")) {
                    System.out.println("Enter a valid 10-digit phone number");
                } else if (newPhone.equals(currentUser.getPhone())) {
                    System.out.println("Unable to update phone: New phone number is identical to your current phone number.");
                } else if (userService.findByPhone(newPhone) != null) {
                    System.out.println("Unable to update phone: The phone number '" + newPhone + "' is already registered to another account.");
                } else if (userService.changePhoneForPhone(currentUser.getPhone(), newPhone)) {
                    System.out.println("Phone updated successfully");
                } else {
                    System.out.println("Unable to update phone: User not found.");
                }
                break;

            case 4:
                System.out.println("Enter current password");
                String oldPassword = sc.nextLine();
                System.out.println("Enter new password");
                String newPassword = sc.nextLine();
                if (!isValidPassword(newPassword)) {
                    System.out.println("Password must be at least 8 characters and include an uppercase letter, a number, and a special character.");
                } else if (!AuthService.verifyPassword(oldPassword, currentUser.getPasswordHash())) {
                    System.out.println("Password change failed: Current password is incorrect.");
                } else if (AuthService.verifyPassword(newPassword, currentUser.getPasswordHash())) {
                    System.out.println("Password change failed: New password cannot be the same as your current password.");
                } else if (userService.changePasswordForPhone(
                        getOperationUser().getPhone(), oldPassword, newPassword)) {
                    System.out.println("Password changed successfully");
                } else {
                    System.out.println("Password change failed: User not found.");
                }
                break;

            case 5:
                break;

            default:
                System.out.println("Invalid choice");
        }
    }
    private static boolean isValidPassword(String password) {
        return password != null && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public static void runForTargetMember(Runnable operation) {
        if (currentUser == null || operation == null) {
            System.out.println("Please log in before performing this operation.");
            return;
        }
        System.out.println("Enter the member's phone number or email (0 to cancel):");
        String identifier = sc.nextLine().trim();
        if (identifier.isEmpty() || identifier.equals("0")) return;

        User target = userService.findByPhone(identifier);
        if (target == null && identifier.contains("@")) {
            target = userService.findByEmail(identifier);
        }
        if (target == null) {
            System.out.println("No account found for that phone number or email.");
            return;
        }
        if (target.getRole() != UserRole.MEMBER) {
            System.out.println("This operation is for member accounts only. The selected account is " + target.getRole() + ".");
            return;
        }
        if (target.getStatus() != UserStatus.ACTIVE) {
            System.out.println("This member account is not active. Activate the account before continuing.");
            return;
        }

        operationTargetUser = target;
        try {
            System.out.println("Selected member: " + target.getName() + " | Phone: " + target.getPhone() + " | Email: " + target.getEmail());
            operation.run();
        } finally {
            operationTargetUser = null;
        }
    }
    private static User operationTargetUser;

    private static User getOperationUser() {

        return operationTargetUser != null ? operationTargetUser : currentUser;
    }
}
