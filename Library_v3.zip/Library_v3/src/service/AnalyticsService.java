package service;

import model.AnalyticsDashboard;
import model.Book;
import model.Transaction;
import model.User;
import repository.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;

public class AnalyticsService {
    private final BookRepository books;
    private final TransactionRepository transactions;
    private final UserRepository users;


    public AnalyticsService(BookRepository books, TransactionRepository transactions, UserRepository users,
                            PaymentRepository payments, BookCopyRepository bookCopies,
                            MembershipRepository memberships, FineRepository fines,
                            MembershipPlanRepository membershipPlans) {
        this.books = books;
        this.transactions = transactions;
        this.users = users;
    }


    public Map<String, Integer> getMostBorrowedBooks(LocalDate startDate, LocalDate endDate) {
        Map<String, Integer> result = new LinkedHashMap<>();
        if (startDate == null || endDate == null || endDate.isBefore(startDate)) {
            return result;
        }

        LocalDateTime start = startDate.atStartOfDay();
        LocalDateTime end = endDate.plusDays(1).atStartOfDay();
        for (Transaction transaction : transactions.findAll()) {
            LocalDateTime issueDate = transaction.getIssueDate();
            if (issueDate == null || issueDate.isBefore(start) || !issueDate.isBefore(end)) {
                continue;
            }

            Book book = books.findById(transaction.getBookId());
            if (book != null) {
                result.put(book.getTitle(), result.getOrDefault(book.getTitle(), 0) + 1);
            }
        }
        return sortByBorrowCount(result);
    }

    public Map<String, Integer> getMostBorrowedBooksForMonth(YearMonth month) {
        if (month == null) return new LinkedHashMap<>();
        return getMostBorrowedBooks(month.atDay(1), month.atEndOfMonth());
    }



    public AnalyticsDashboard getDashboardForYear(int year) {
        int totalUsersInSystem = users.findAll().size();
        int totalRegistrationsInYear = 0;
        int[] monthlyRegistrations = new int[12];
        Map<Integer, Map<String, Integer>> monthlyRegistrationsByGender = new LinkedHashMap<>();
        for (int m = 1; m <= 12; m++) {
            monthlyRegistrationsByGender.put(m, new LinkedHashMap<>());
        }

        Map<String, Integer> byAge = new LinkedHashMap<>();
        byAge.put("0-17", 0);
        byAge.put("18-25", 0);
        byAge.put("26-35", 0);
        byAge.put("36-50", 0);
        byAge.put("51+", 0);
        byAge.put("AGE_NOT_PROVIDED", 0);

        Map<String, Integer> byGender = new LinkedHashMap<>();

        for (User user : users.findAll()) {
            LocalDateTime created = user.getCreatedAt();
            if (created == null || created.getYear() != year) continue;

            totalRegistrationsInYear++;
            int m = created.getMonthValue();
            monthlyRegistrations[m - 1]++;

            String gender = user.getGender() == null || user.getGender().isBlank()
                    ? "UNSPECIFIED" : user.getGender().trim().toUpperCase();
            byGender.put(gender, byGender.getOrDefault(gender, 0) + 1);

            Map<String, Integer> monthGenderMap = monthlyRegistrationsByGender.get(m);
            monthGenderMap.put(gender, monthGenderMap.getOrDefault(gender, 0) + 1);

            int age = user.getAge();
            String ageGroup = age <= 0 ? "AGE_INVALID" : age <= 17 ? "0-17" : age <= 25 ? "18-25"
                    : age <= 35 ? "26-35" : age <= 50 ? "36-50" : "51+";
            byAge.put(ageGroup, byAge.getOrDefault(ageGroup, 0) + 1);
        }

        int totalBorrowingsInYear = 0;
        int[] monthlyBorrowings = new int[12];
        Map<Integer, Map<String, Integer>> monthlyBorrowingByBook = new LinkedHashMap<>();
        for (int m = 1; m <= 12; m++) {
            monthlyBorrowingByBook.put(m, new LinkedHashMap<>());
        }
        Map<Integer, Integer> bookBorrowCountsForYear = new LinkedHashMap<>();

        for (Transaction tx : transactions.findAll()) {
            LocalDateTime issueDate = tx.getIssueDate();
            if (issueDate == null || issueDate.getYear() != year) continue;

            totalBorrowingsInYear++;
            int m = issueDate.getMonthValue();
            monthlyBorrowings[m - 1]++;

            int bId = tx.getBookId();
            bookBorrowCountsForYear.put(bId, bookBorrowCountsForYear.getOrDefault(bId, 0) + 1);

            Book book = books != null ? books.findById(bId) : null;
            String bookLabel = book != null
                    ? book.getTitle() + " (ISBN: " + book.getIsbn() + ")"
                    : "Book ID " + bId;
            Map<String, Integer> monthBookMap = monthlyBorrowingByBook.get(m);
            monthBookMap.put(bookLabel, monthBookMap.getOrDefault(bookLabel, 0) + 1);
        }

        List<AnalyticsDashboard.BorrowedBookDetail> borrowedBookRankings = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : bookBorrowCountsForYear.entrySet()) {
            Book book = books != null ? books.findById(entry.getKey()) : null;
            String title = book != null ? book.getTitle() : "Book ID " + entry.getKey();
            String isbn = book != null ? book.getIsbn() : "N/A";
            borrowedBookRankings.add(new AnalyticsDashboard.BorrowedBookDetail(isbn, title, entry.getValue()));
        }
        borrowedBookRankings.sort((a, b) -> Integer.compare(b.getCount(), a.getCount()));

        Map<String, Integer> mostBorrowedBooksForYear = new LinkedHashMap<>();
        for (AnalyticsDashboard.BorrowedBookDetail detail : borrowedBookRankings) {
            mostBorrowedBooksForYear.put(detail.getTitle(), detail.getCount());
        }

        Map<String, Map<String, Integer>> booksByMonth = new LinkedHashMap<>();
        for (int m = 1; m <= 12; m++) {
            YearMonth ym = YearMonth.of(year, m);
            booksByMonth.put(ym.getMonth().toString(), getMostBorrowedBooksForMonth(ym));
        }

        return new AnalyticsDashboard(
                year,
                totalUsersInSystem,
                totalRegistrationsInYear,
                monthlyRegistrations,
                monthlyRegistrationsByGender,
                byAge,
                byGender,
                totalBorrowingsInYear,
                monthlyBorrowings,
                borrowedBookRankings,
                monthlyBorrowingByBook,
                mostBorrowedBooksForYear,
                booksByMonth

        );
    }

    private Map<String, Integer> sortByBorrowCount(Map<String, Integer> counts) {
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((first, second) -> Integer.compare(second.getValue(), first.getValue()));

        Map<String, Integer> sorted = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : entries) {
            sorted.put(entry.getKey(), entry.getValue());
        }
        return sorted;
    }
}
