# LMS Dead-Code Cleanup Report

This cleanup removes methods that had no call sites in the application or test sources. No whole service class was removed because each service class is referenced by the application or another live service.

## Removed unused UI helpers
- `Librarian.viewSingleFineDetails`
- `Librarian.recordFinePayment`
- `Librarian.waiveFineAction`
- `Librarian.memberOperations`
- `Librarian.lookupMemberAccount`
- `UiHelpers.promptSearch`

## Removed unused service methods
- `BookService.updateBookAuthorsAndGenres`
- `FineService.findOverdueFineByTransactionId`
- `OverdueFineSchedulerService.getDateSupplier`
- `UserService.getProfileByPhone`
- `UserService.changePasswordByEmail`
- `PolicyService.setMembershipPlanRepository`
- `PolicyService.getMaxBooksBorrowed`
- `PolicyService.getActiveStaff`
- `BookTransactionService.processPendingRequest`
- `BookTransactionService.expireStaleReservations`
- `BookTransactionService.getNextEligibleQueuedRequest`
- `BookTransactionService.getPrioritizedPendingRequests`
- `BookTransactionService.assignNextEligibleRequest`
- `BookTransactionService.notifyStaffIfWaitingRequests`

## Removed unused model methods
- `Book.removeAuthor`, `Book.clearAuthors`, `Book.removeCategory`, `Book.removeGenre`, `Book.clearGenres`
- `Audit.getAction`, `Audit.getTimestamp`, `Audit.getDetails`
- `Transaction.getReservedDate`, `Transaction.getReadyDate`
- `Membership.getStartDate`
- `BookCopy.getAcquiredDate`, `BookCopy.markAvailable`, `BookCopy.isReserved`, `BookCopy.isIssued`
- `Fine.reversePayment`
- Unused `AnalyticsDashboard` accessors and role-based registration analytics fields

## Analytics cleanup
The dashboard continues to report registration counts by age group and gender, plus most-borrowed books by month, quarter, and year. Unused role-based registration calculations were removed. The quarterly display now calls `getMostBorrowedBooksByQuarter()` rather than mistakenly printing the yearly result.

## Validation
- All Java application sources compiled with `javac -Xlint:all` using a temporary BCrypt stub because the BCrypt dependency was not available in this execution environment.
- One existing warning remains in `model.Book`: possible `this` escape during constructor initialization.
- Maven/JUnit tests were not run in this environment.
